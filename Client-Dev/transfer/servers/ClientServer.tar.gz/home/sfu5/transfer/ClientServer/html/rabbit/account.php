<?php
$hostname = "localhost";
$username = "testuser";
$project = "testdb";
$password = "njit";




?>
