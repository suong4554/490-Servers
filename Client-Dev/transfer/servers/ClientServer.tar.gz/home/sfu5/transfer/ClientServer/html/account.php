<?php
$servername = "localhost";
$username = "sfu5";
$project = "matches";
$password = "njit";




?>
